
import SwiftUI
import Charts
import AVFoundation

// MARK: - View Extensions
extension View {
    func dismissKeyboardOnTap() -> some View {
        self.onTapGesture {
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder),
                                            to: nil, from: nil, for: nil)
        }
    }
}

// MARK: - Models
struct DailyBattery: Identifiable, Codable, Equatable {
    var id: UUID
    let date: Date
    var batteryLevel: Double
    
    init(id: UUID = UUID(), date: Date, batteryLevel: Double) {
        self.id = id
        self.date = date
        self.batteryLevel = batteryLevel
    }
}

struct DailyJournal: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    let date: Date
    var moodEmoji: String
    var challengingThoughts: String
    var quickNotes: String
    var moodText: String
    var activitiesEntry: String
    var selfcareEntry: String
    var socialTags: [String]
    
    init(date: Date,
         moodEmoji: String,
         challengingThoughts: String,
         quickNotes: String,
         moodText: String,
         activitiesEntry: String,
         selfcareEntry: String,
         socialTags: [String]) {
        self.date = date
        self.moodEmoji = moodEmoji
        self.challengingThoughts = challengingThoughts
        self.quickNotes = quickNotes
        self.moodText = moodText
        self.activitiesEntry = activitiesEntry
        self.selfcareEntry = selfcareEntry
        self.socialTags = socialTags
    }
}

// MARK: - ContentView
struct ContentView: View {
    @AppStorage("batteryData") private var batteryData: Data?
    @State private var dailyBatteries: [DailyBattery] = []
    
    @AppStorage("journalData") private var journalData: Data?
    @State private var dailyJournals: [DailyJournal] = []
    
    @AppStorage("name") var name: String = "Friend"
    
    // Home-View States
    @State private var selectedMood: String = "😐"
    @State private var energyLevel: Double = 70
    @State private var quickNotes: String = ""
    @State private var challengingThoughts: String = ""
    
    // Tab-Auswahl
    @State private var selectedTab: Int = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationView {
                HomeView(
                    name: $name,
                    selectedMood: $selectedMood,
                    energyLevel: $energyLevel,
                    quickNotes: $quickNotes,
                    challengingThoughts: $challengingThoughts,
                    dailyBatteries: $dailyBatteries,
                    saveDailyBatteries: saveDailyBatteries,
                    dailyJournals: $dailyJournals,
                    saveDailyJournals: saveDailyJournals
                )
                .navigationTitle("Home")
            }
            .tabItem {
                Image(systemName: "house.fill")
                Text("Home")
            }
            .tag(0)
            
            NavigationView {
                JournalView(
                    dailyJournals: $dailyJournals,
                    saveDailyJournals: saveDailyJournals
                )
                .navigationTitle("Journal")
            }
            .tabItem {
                Image(systemName: "book.fill")
                Text("Journal")
            }
            .tag(1)
            
            NavigationView {
                MonthlyCalendarView(
                    dailyBatteries: $dailyBatteries,
                    dailyJournals: $dailyJournals
                )
                .navigationTitle("Calendar")
            }
            .tabItem {
                Image(systemName: "calendar")
                Text("Calendar")
            }
            .tag(2)
            
            NavigationView {
                RelaxView()
                    .navigationTitle("Relax")
            }
            .tabItem {
                Image(systemName: "drop.fill")
                Text("Relax")
            }
            .tag(3)
        }
        .onAppear {
            loadDailyBatteries()
            loadDailyJournals()
        }
    }
    
    // MARK: - Battery Data Handling
    private func loadDailyBatteries() {
        guard let batteryData = batteryData else { return }
        do {
            let decoded = try JSONDecoder().decode([DailyBattery].self, from: batteryData)
            dailyBatteries = decoded
        } catch {
            print("Error decoding battery data: \(error)")
        }
    }
    
    private func saveDailyBatteries() {
        do {
            let encoded = try JSONEncoder().encode(dailyBatteries)
            batteryData = encoded
        } catch {
            print("Error encoding battery data: \(error)")
        }
    }
    
    // MARK: - Journal Data Handling
    private func loadDailyJournals() {
        guard let journalData = journalData else { return }
        do {
            let decoded = try JSONDecoder().decode([DailyJournal].self, from: journalData)
            dailyJournals = decoded
        } catch {
            print("Error decoding journal data: \(error)")
        }
    }
    
    private func saveDailyJournals() {
        do {
            let encoded = try JSONEncoder().encode(dailyJournals)
            journalData = encoded
        } catch {
            print("Error encoding journal data: \(error)")
        }
    }
}

struct HomeView: View {
    @Binding var name: String
    @Binding var selectedMood: String
    @Binding var energyLevel: Double
    @Binding var quickNotes: String
    @Binding var challengingThoughts: String
    
    @Binding var dailyBatteries: [DailyBattery]
    let saveDailyBatteries: () -> Void
    
    @Binding var dailyJournals: [DailyJournal]
    let saveDailyJournals: () -> Void
    
    @State private var showSavedPopup = false
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 30) {
                Text("Hi, \(name)!")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                Text(formattedDate())
                    .font(.subheadline)
                    .foregroundColor(.gray)
                
                Text("How do you feel?")
                    .font(.title)
                
                moodScrollView
                
                Text("Have you had any challenging or uncomfortable thoughts today?")
                    .font(.system(size: 20))
                
                yesNoButtons
                
                if challengingThoughts == "Yes" {
                    Text("If you feel depressed or distressed, please consider seeking professional help.")
                        .font(.footnote)
                        .foregroundColor(.gray)
                }
                
                Text("Quick Notes")
                    .font(.headline)
                
                ZStack(alignment: .topLeading) {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.gray.opacity(0.1))
                    
                    TextField("...", text: $quickNotes, axis: .vertical)
                        .padding()
                }
                .frame(height: 80)
                
                Text("Set Your Social Battery:")
                    .font(.headline)
                
                Slider(value: $energyLevel, in: 0...100, step: 10)
                    .accentColor(colorForBattery(energyLevel))
                    .padding(.horizontal)
                
                HStack {
                    Text("Battery: \(Int(energyLevel))%")
                        .fontWeight(.bold)
                        .foregroundColor(colorForBattery(energyLevel))
                    Spacer()
                }
                
                Button {
                    updateBatteryRecord(energyLevel)
                    saveDailyBatteries()
                    updateTodayJournalEntry()
                    showPopupTemporarily()
                } label: {
                    Text("Done")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(15)
                }
                
                Text("Battery Trend")
                    .font(.headline)
                    .padding(.top, 16)
                
                batteryChartView
                
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top, 20)
        }
        .dismissKeyboardOnTap()
        .animation(.easeInOut, value: showSavedPopup)
        .overlay(savedPopupOverlay)
        .onAppear {
            loadTodayData()
        }
    }
    
    // MARK: - Data Handling
    private func loadTodayData() {
        let today = Date()
        if let existingBattery = dailyBatteries.first(where: { Calendar.current.isDate($0.date, inSameDayAs: today) }) {
            energyLevel = existingBattery.batteryLevel
        }
        if let existingJournal = dailyJournals.first(where: { Calendar.current.isDate($0.date, inSameDayAs: today) }) {
            selectedMood = existingJournal.moodEmoji
            challengingThoughts = existingJournal.challengingThoughts
            quickNotes = existingJournal.quickNotes
        }
    }
    
    private func updateTodayJournalEntry() {
        let today = Date()
        if let index = dailyJournals.firstIndex(where: { Calendar.current.isDate($0.date, inSameDayAs: today) }) {
            dailyJournals[index].moodEmoji = selectedMood
            dailyJournals[index].challengingThoughts = challengingThoughts
            dailyJournals[index].quickNotes = quickNotes
        } else {
            let newEntry = DailyJournal(
                date: today,
                moodEmoji: selectedMood,
                challengingThoughts: challengingThoughts,
                quickNotes: quickNotes,
                moodText: "",
                activitiesEntry: "",
                selfcareEntry: "",
                socialTags: []
            )
            dailyJournals.append(newEntry)
        }
        saveDailyJournals()
    }
    
    private func updateBatteryRecord(_ newLevel: Double) {
        let today = Date()
        if let index = dailyBatteries.firstIndex(where: { Calendar.current.isDate($0.date, inSameDayAs: today) }) {
            dailyBatteries[index].batteryLevel = newLevel
        } else {
            dailyBatteries.append(DailyBattery(date: today, batteryLevel: newLevel))
        }
    }
    
    private func showPopupTemporarily() {
        showSavedPopup = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            showSavedPopup = false
        }
    }
    
    // MARK: - Subviews
    private var moodScrollView: some View {
        let moods = ["😡", "😭", "😐", "😊", "😁", "🥰", "🥳", "😴"]
        return ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(moods, id: \.self) { mood in
                    Text(mood)
                        .font(.largeTitle)
                        .padding()
                        .background(selectedMood == mood ? Color.gray.opacity(0.3) : Color.gray.opacity(0.1))
                        .cornerRadius(10)
                        .onTapGesture {
                            selectedMood = mood
                        }
                }
            }
            .padding(.vertical, 4)
        }
    }
    
    private var yesNoButtons: some View {
        HStack(spacing: 15) {
            Button {
                challengingThoughts = (challengingThoughts == "Yes") ? "" : "Yes"
            } label: {
                Text("Yes")
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .foregroundColor(challengingThoughts == "Yes" ? .white : .primary)
                    .background(challengingThoughts == "Yes" ? Color.blue : Color.gray.opacity(0.2))
                    .cornerRadius(15)
            }
            Button {
                challengingThoughts = (challengingThoughts == "No") ? "" : "No"
            } label: {
                Text("No")
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .foregroundColor(challengingThoughts == "No" ? .white : .primary)
                    .background(challengingThoughts == "No" ? Color.blue : Color.gray.opacity(0.2))
                    .cornerRadius(15)
            }
        }
    }
    
    private var batteryChartView: some View {
        let recentBatteries = dailyBatteries.sorted(by: { $0.date < $1.date }).suffix(7)
        if recentBatteries.isEmpty {
            return AnyView(Text("No data yet.").foregroundColor(.gray))
        } else {
            return AnyView(
                Chart(recentBatteries) { item in
                    LineMark(
                        x: .value("Day", dayAbbreviation(from: item.date)),
                        y: .value("Battery", item.batteryLevel)
                    )
                    .symbol(by: .value("Day", dayAbbreviation(from: item.date)))
                    .foregroundStyle(.blue)
                }
                    .frame(height: 200)
                    .padding(.vertical, 8)
            )
        }
    }
    
    // MARK: - Overlays
    private var savedPopupOverlay: some View {
        Group {
            if showSavedPopup {
                ZStack {
                    Color.black.opacity(0.25).ignoresSafeArea()
                    VStack(spacing: 10) {
                        Image(systemName: "checkmark.circle")
                            .resizable()
                            .foregroundColor(.green)
                            .frame(width: 50, height: 50)
                        
                        Text("Saved")
                            .font(.headline)
                            .foregroundColor(.green)
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(10)
                    .shadow(radius: 4)
                }
                .transition(.opacity)
            }
        }
    }
    
    // MARK: - Helpers
    private func formattedDate() -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: Date())
    }
    
    private func dayAbbreviation(from date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "E"
        return formatter.string(from: date)
    }
    
    private func colorForBattery(_ energy: Double) -> Color {
        switch energy {
        case 0..<30: return .red
        case 30..<60: return .yellow
        default:     return .green
        }
    }
}

struct JournalView: View {
    @Binding var dailyJournals: [DailyJournal]
    let saveDailyJournals: () -> Void
    
    @State private var moodText: String = ""
    @State private var activitiesEntry: String = ""
    @State private var selfcareEntry: String = ""
    
    let socialTags = ["Partner", "Parent(s)", "Sibling(s)", "Friend(s)", "Best Friend", "Grandparent(s)", "Other"]
    @State private var selectedTags = Set<String>()
    
    @State private var showSavedPopup = false
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Journal")
                    .font(.title)
                    .fontWeight(.bold)
                
                Text("Today, \(todayFormatted)")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                
                Text("Today's Mood")
                    .font(.headline)
                ZStack(alignment: .topLeading) {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.gray.opacity(0.1))
                    
                    TextField("How did you feel today and why?",
                              text: $moodText, axis: .vertical)
                    .padding()
                }
                .frame(height: 80)
                
                Text("Today's Activities")
                    .font(.headline)
                ZStack(alignment: .topLeading) {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.gray.opacity(0.1))
                    
                    TextField("Which moments or activities defined your day?",
                              text: $activitiesEntry, axis: .vertical)
                    .padding()
                }
                .frame(height: 80)
                
                Text("Selfcare")
                    .font(.headline)
                ZStack(alignment: .topLeading) {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.gray.opacity(0.1))
                    
                    TextField("How did you care for yourself or lift your mood?",
                              text: $selfcareEntry, axis: .vertical)
                    .padding()
                }
                .frame(height: 80)
                
                Text("Social Interactions")
                    .font(.headline)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(socialTags, id: \.self) { tag in
                            Text(tag)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(
                                    selectedTags.contains(tag)
                                    ? Color.blue.opacity(0.3)
                                    : Color.gray.opacity(0.2)
                                )
                                .cornerRadius(15)
                                .onTapGesture {
                                    if selectedTags.contains(tag) {
                                        selectedTags.remove(tag)
                                    } else {
                                        selectedTags.insert(tag)
                                    }
                                }
                        }
                    }
                    .padding(.vertical, 4)
                }
                
                Button {
                    dismissKeyboard()
                    saveOrUpdateJournalEntry()
                    saveDailyJournals()
                    
                    showSavedPopup = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        showSavedPopup = false
                    }
                } label: {
                    Text("Done")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(15)
                }
                .padding(.top, 10)
            }
            .padding()
        }
        .dismissKeyboardOnTap()
        .overlay(journalSavedOverlay)
        .animation(.easeInOut, value: showSavedPopup)
        .onAppear { loadTodayJournal() }
    }
    
    private var todayFormatted: String {
        let f = DateFormatter()
        f.dateStyle = .medium
        return f.string(from: Date())
    }
    
    private func loadTodayJournal() {
        let today = Date()
        if let index = dailyJournals.firstIndex(where: {
            Calendar.current.isDate($0.date, inSameDayAs: today)
        }) {
            let existing = dailyJournals[index]
            moodText = existing.moodText
            activitiesEntry = existing.activitiesEntry
            selfcareEntry = existing.selfcareEntry
            selectedTags = Set(existing.socialTags)
        }
    }
    
    private func saveOrUpdateJournalEntry() {
        let today = Date()
        if let index = dailyJournals.firstIndex(where: {
            Calendar.current.isDate($0.date, inSameDayAs: today)
        }) {
            dailyJournals[index].moodText = moodText
            dailyJournals[index].activitiesEntry = activitiesEntry
            dailyJournals[index].selfcareEntry = selfcareEntry
            dailyJournals[index].socialTags = Array(selectedTags)
        } else {
            let newJournal = DailyJournal(
                date: today,
                moodEmoji: "",
                challengingThoughts: "",
                quickNotes: "",
                moodText: moodText,
                activitiesEntry: activitiesEntry,
                selfcareEntry: selfcareEntry,
                socialTags: Array(selectedTags)
            )
            dailyJournals.append(newJournal)
        }
    }
    
    private func dismissKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder),
                                        to: nil, from: nil, for: nil)
    }
    
    private var journalSavedOverlay: some View {
        Group {
            if showSavedPopup {
                ZStack {
                    Color.black.opacity(0.25).ignoresSafeArea()
                    VStack(spacing: 10) {
                        Image(systemName: "checkmark.circle")
                            .resizable()
                            .foregroundColor(.green)
                            .frame(width: 50, height: 50)
                        
                        Text("Saved")
                            .font(.headline)
                            .foregroundColor(.green)
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(10)
                    .shadow(radius: 4)
                }
                .transition(.opacity)
            }
        }
    }
}

struct MonthlyCalendarView: View {
    @Binding var dailyBatteries: [DailyBattery]
    @Binding var dailyJournals: [DailyJournal]
    
    @State private var displayedMonth: Date = Date()
    @State private var selectedDay: Date? = nil
    @State private var showFullDetailSheet = false
    @State private var showEditSheet = false
    @State private var forceRefresh = UUID()
    
    var body: some View {
        VStack {
            Text(monthTitle(for: displayedMonth))
                .font(.title)
                .padding(.bottom, 4)
            
            let columns = Array(repeating: GridItem(.flexible()), count: 7)
            LazyVGrid(columns: columns, spacing: 8) {
                ForEach(["Mo","Di","Mi","Do","Fr","Sa","So"], id: \.self) { weekday in
                    Text(weekday)
                        .font(.headline)
                        .foregroundColor(.gray)
                }
                
                let days = generateDays(for: displayedMonth)
                ForEach(days, id: \.self) { day in
                    DayCell(
                        day: day,
                        displayedMonth: displayedMonth,
                        dailyBatteries: dailyBatteries,
                        dailyJournals: dailyJournals
                    )
                    .onTapGesture {
                        if day != .distantPast && isSameMonth(day, displayedMonth) {
                            selectedDay = day
                        }
                    }
                }
            }
            .padding(.horizontal, 4)
            
            if let selDay = selectedDay, isSameMonth(selDay, displayedMonth) {
                let battery = dailyBatteries.first(where: { isSameDay($0.date, selDay) })
                let journal = dailyJournals.first(where: { isSameDay($0.date, selDay) })
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("\(formattedDay(selDay))")
                        .font(.headline)
                    
                    if let b = battery {
                        Text("Battery: \(Int(b.batteryLevel))%")
                            .foregroundColor(.blue)
                    }
                    if let j = journal {
                        Text("Feeling: \(j.moodEmoji)")
                            .foregroundColor(.purple)
                        
                        if !j.quickNotes.isEmpty {
                            Text("Quick Notes: \(j.quickNotes)")
                        }
                    }
                    
                    if battery == nil && journal == nil {
                        Text("No entry for this day.")
                            .foregroundColor(.gray)
                    }
                    
                    HStack {
                        Spacer()
                        Button {
                            showEditSheet = true
                        } label: {
                            Image(systemName: "plus.circle.fill")
                                .font(.system(size: 30))
                        }
                        if battery != nil || journal != nil {
                            Button {
                                showFullDetailSheet = true
                            } label: {
                                Image(systemName: "arrow.right.circle.fill")
                                    .font(.system(size: 30))
                            }
                        }
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                .padding(.horizontal)
                .transition(.opacity)
                .sheet(isPresented: $showFullDetailSheet) {
                    CalendarFullDetailView(day: selDay, battery: battery, journal: journal)
                }
                .sheet(isPresented: $showEditSheet) {
                    EditEntryView(selectedDate: selDay,
                                  dailyBatteries: $dailyBatteries,
                                  dailyJournals: $dailyJournals)
                }
            }
            
            Spacer()
            
            HStack {
                Button {
                    displayedMonth = previousMonth(displayedMonth)
                    selectedDay = nil
                } label: {
                    HStack {
                        Image(systemName: "chevron.left.circle.fill")
                        Text("Previous")
                    }
                }
                
                Spacer()
                
                Button {
                    displayedMonth = nextMonth(displayedMonth)
                    selectedDay = nil
                } label: {
                    HStack {
                        Text("Next")
                        Image(systemName: "chevron.right.circle.fill")
                    }
                }
            }
            .padding(.horizontal, 40)
            .padding(.bottom, 16)
        }
        .padding(.top)
        .id(forceRefresh)
        .onChange(of: dailyBatteries) { oldValue, newValue in
            forceRefresh = UUID()
        }
        .onChange(of: dailyJournals) { oldValue, newValue in
            forceRefresh = UUID()
        }
    }
    
    // MARK: - Helper Methods
    private func generateDays(for date: Date) -> [Date] {
        let cal = Calendar.current
        guard let startOfMonth = cal.date(from: cal.dateComponents([.year, .month], from: date)) else { return [] }
        let weekdayOfStart = cal.component(.weekday, from: startOfMonth)
        let offset = (weekdayOfStart + 5) % 7
        
        let range = cal.range(of: .day, in: .month, for: startOfMonth) ?? 1..<1
        var days: [Date] = []
        for _ in 0..<offset {
            days.append(.distantPast)
        }
        for day in 1...range.count {
            if let realDate = cal.date(byAdding: .day, value: day - 1, to: startOfMonth) {
                days.append(realDate)
            }
        }
        return days
    }
    
    private func monthTitle(for date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "LLLL yyyy"
        return formatter.string(from: date)
    }
    
    private func nextMonth(_ date: Date) -> Date {
        Calendar.current.date(byAdding: .month, value: 1, to: date) ?? date
    }
    
    private func previousMonth(_ date: Date) -> Date {
        Calendar.current.date(byAdding: .month, value: -1, to: date) ?? date
    }
    
    private func isSameMonth(_ d1: Date, _ d2: Date) -> Bool {
        let cal = Calendar.current
        let comp1 = cal.dateComponents([.year, .month], from: d1)
        let comp2 = cal.dateComponents([.year, .month], from: d2)
        return comp1.year == comp2.year && comp1.month == comp2.month
    }
    
    private func isSameDay(_ d1: Date, _ d2: Date) -> Bool {
        Calendar.current.isDate(d1, inSameDayAs: d2)
    }
    
    private func formattedDay(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
}

struct DayCell: View {
    let day: Date
    let displayedMonth: Date
    let dailyBatteries: [DailyBattery]
    let dailyJournals: [DailyJournal]
    
    var body: some View {
        if day == .distantPast {
            Rectangle()
                .fill(Color.clear)
                .frame(height: 30)
        } else {
            let inCurrentMonth = isSameMonth(day, displayedMonth)
            let dayNumber = Calendar.current.component(.day, from: day)
            let hasBattery = dailyBatteries.contains { Calendar.current.isDate($0.date, inSameDayAs: day) }
            let hasJournal = dailyJournals.contains { Calendar.current.isDate($0.date, inSameDayAs: day) }
            let hasEntry = hasBattery || hasJournal
            let isTodayCell = isToday(day) && inCurrentMonth
            
            VStack(spacing: 4) {
                Text("\(dayNumber)")
                    .foregroundColor(inCurrentMonth ? .primary : .gray)
                    .fontWeight(hasEntry ? .bold : .regular)
                    .background(isTodayCell ? Circle().fill(Color.red.opacity(0.3)).frame(width: 30, height: 30) : nil)
                
                if hasEntry {
                    Circle()
                        .fill(Color.blue)
                        .frame(width: 6, height: 6)
                        .offset(y: 2)
                }
            }
            .frame(height: 40)
        }
    }
    
    private func isSameMonth(_ d1: Date, _ d2: Date) -> Bool {
        let cal = Calendar.current
        let comp1 = cal.dateComponents([.year, .month], from: d1)
        let comp2 = cal.dateComponents([.year, .month], from: d2)
        return comp1.year == comp2.year && comp1.month == comp2.month
    }
    
    private func isToday(_ date: Date) -> Bool {
        Calendar.current.isDate(date, inSameDayAs: Date())
    }
}

struct CalendarFullDetailView: View {
    let day: Date
    let battery: DailyBattery?
    let journal: DailyJournal?
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text(formattedDay(day))
                        .font(.title2)
                        .fontWeight(.semibold)
                    
                    if let b = battery {
                        Text("Battery: \(Int(b.batteryLevel))%")
                            .foregroundColor(.blue)
                    } else {
                        Text("No Battery Entry.")
                            .foregroundColor(.gray)
                    }
                    
                    if let j = journal {
                        Text("Mood: \(j.moodEmoji)")
                            .foregroundColor(.purple)
                        
                        if !j.challengingThoughts.isEmpty {
                            Text("Challenging Thoughts: \(j.challengingThoughts)")
                        }
                        if !j.quickNotes.isEmpty {
                            Text("Quick Notes: \(j.quickNotes)")
                        }
                        if !j.moodText.isEmpty {
                            Text("Mood Description: \(j.moodText)")
                        }
                        if !j.activitiesEntry.isEmpty {
                            Text("Activities: \(j.activitiesEntry)")
                        }
                        if !j.selfcareEntry.isEmpty {
                            Text("Selfcare: \(j.selfcareEntry)")
                        }
                        if !j.socialTags.isEmpty {
                            Text("Social: \(j.socialTags.joined(separator: ", "))")
                        }
                    } else {
                        Text("No Journal Entry.")
                            .foregroundColor(.gray)
                    }
                    
                    Spacer()
                }
                .padding()
            }
            .navigationBarTitle("Details", displayMode: .inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
        }
    }
    
    @Environment(\.presentationMode) var presentationMode
    
    private func formattedDay(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
}

struct EditEntryView: View {
    let selectedDate: Date
    @Binding var dailyBatteries: [DailyBattery]
    @Binding var dailyJournals: [DailyJournal]
    
    @State private var moodEmoji: String = "😐"
    @State private var challengingThoughts: String = "No"
    @State private var batteryLevel: Double = 50
    
    @State private var moodText: String = ""
    @State private var activitiesEntry: String = ""
    @State private var selfcareEntry: String = ""
    
    @State private var socialTags: Set<String> = []
    let socialTagsOptions = ["Partner", "Parent(s)", "Sibling(s)", "Friend(s)", "Best Friend", "Grandparent(s)", "Other"]
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text(formattedDay(selectedDate))
                        .font(.title)
                        .fontWeight(.bold)
                    
                    Text("How do you feel?")
                        .font(.headline)
                    moodScrollView
                    
                    Text("Have you had any challenging or uncomfortable thoughts today?")
                        .font(.subheadline)
                    yesNoButtons
                    
                    Text("Set Your Social Battery:")
                        .font(.headline)
                    Slider(value: $batteryLevel, in: 0...100, step: 10)
                        .accentColor(colorForBattery(batteryLevel))
                    Text("Battery: \(Int(batteryLevel))%")
                        .foregroundColor(colorForBattery(batteryLevel))
                    
                    Text("Today's Mood")
                        .font(.headline)
                    TextField("How did you feel today and why?", text: $moodText, axis: .vertical)
                        .padding()
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(10)
                    
                    Text("Today's Activities")
                        .font(.headline)
                    TextField("Which moments or activities defined your day?", text: $activitiesEntry, axis: .vertical)
                        .padding()
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(10)
                    
                    Text("Selfcare")
                        .font(.headline)
                    TextField("How did you care for yourself or lift your mood?", text: $selfcareEntry, axis: .vertical)
                        .padding()
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(10)
                    
                    Text("Social Interactions")
                        .font(.headline)
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(socialTagsOptions, id: \.self) { tag in
                                Text(tag)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .background(socialTags.contains(tag) ? Color.blue.opacity(0.3) : Color.gray.opacity(0.2))
                                    .cornerRadius(15)
                                    .onTapGesture {
                                        if socialTags.contains(tag) {
                                            socialTags.remove(tag)
                                        } else {
                                            socialTags.insert(tag)
                                        }
                                    }
                            }
                        }
                    }
                }
                .padding()
            }
            .navigationBarTitle("Edit Entry", displayMode: .inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        saveEntry()
                    }
                }
            }
        }
        .onAppear {
            loadExistingData()
        }
    }
    
    // MARK: - Data Loading
    private func loadExistingData() {
        if let existingBattery = dailyBatteries.first(where: {
            Calendar.current.isDate($0.date, inSameDayAs: selectedDate)
        }) {
            batteryLevel = existingBattery.batteryLevel
        }
        if let existingJournal = dailyJournals.first(where: {
            Calendar.current.isDate($0.date, inSameDayAs: selectedDate)
        }) {
            moodEmoji = existingJournal.moodEmoji
            challengingThoughts = existingJournal.challengingThoughts
            moodText = existingJournal.moodText
            activitiesEntry = existingJournal.activitiesEntry
            selfcareEntry = existingJournal.selfcareEntry
            socialTags = Set(existingJournal.socialTags)
        }
    }
    
    // MARK: - Saving Data
    private func saveEntry() {
        if let index = dailyBatteries.firstIndex(where: {
            Calendar.current.isDate($0.date, inSameDayAs: selectedDate)
        }) {
            dailyBatteries[index].batteryLevel = batteryLevel
        } else {
            let newBattery = DailyBattery(date: selectedDate, batteryLevel: batteryLevel)
            dailyBatteries.append(newBattery)
        }
        
        if let index = dailyJournals.firstIndex(where: {
            Calendar.current.isDate($0.date, inSameDayAs: selectedDate)
        }) {
            dailyJournals[index].moodEmoji = moodEmoji
            dailyJournals[index].challengingThoughts = challengingThoughts
            dailyJournals[index].moodText = moodText
            dailyJournals[index].activitiesEntry = activitiesEntry
            dailyJournals[index].selfcareEntry = selfcareEntry
            dailyJournals[index].socialTags = Array(socialTags)
        } else {
            let newJournal = DailyJournal(
                date: selectedDate,
                moodEmoji: moodEmoji,
                challengingThoughts: challengingThoughts,
                quickNotes: "",
                moodText: moodText,
                activitiesEntry: activitiesEntry,
                selfcareEntry: selfcareEntry,
                socialTags: Array(socialTags)
            )
            dailyJournals.append(newJournal)
        }
        presentationMode.wrappedValue.dismiss()
    }
    
    // MARK: - Subviews
    private var moodScrollView: some View {
        let moods = ["😡", "😭", "😐", "😊", "😁", "🥰", "🥳", "😴"]
        return ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(moods, id: \.self) { mood in
                    Text(mood)
                        .font(.largeTitle)
                        .padding()
                        .background(moodEmoji == mood ? Color.gray.opacity(0.3) : Color.gray.opacity(0.1))
                        .cornerRadius(10)
                        .onTapGesture {
                            moodEmoji = mood
                        }
                }
            }
        }
    }
    
    private var yesNoButtons: some View {
        HStack(spacing: 15) {
            Button {
                challengingThoughts = "Yes"
            } label: {
                Text("Yes")
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(challengingThoughts == "Yes" ? Color.blue.opacity(0.3) : Color.gray.opacity(0.2))
                    .cornerRadius(15)
            }
            Button {
                challengingThoughts = "No"
            } label: {
                Text("No")
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(challengingThoughts == "No" ? Color.blue.opacity(0.3) : Color.gray.opacity(0.2))
                    .cornerRadius(15)
            }
        }
    }
    
    // MARK: - Helpers
    private func formattedDay(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
    
    private func colorForBattery(_ energy: Double) -> Color {
        switch energy {
        case 0..<30: return .red
        case 30..<60: return .yellow
        default:     return .green
        }
    }
}

struct RelaxView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Relax & Unwind")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.blue)
            BreathingExerciseView()
        }
        .padding()
    }
}

struct BreathingExerciseView: View {
    @State private var selectedExercise: String? = nil
    @State private var isExerciseActive = false
    @State private var currentStep = 0
    @State private var timer: Timer? = nil
    @State private var totalRounds = 3
    @State private var currentRound = 1
    @State private var isExerciseComplete = false
    @State private var starRating = 0
    
    @State private var remainingTime: Int = 0
    @State private var timerPublisher = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    let exercises = [
        "Relax": (inhale: 4, hold: 7, exhale: 8),
        "Focus": (inhale: 4, hold: 0, exhale: 6),
        "Calm":  (inhale: 4, hold: 4, exhale: 4)
    ]
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Breathing Exercises")
                .font(.title)
                .fontWeight(.bold)
            
            if isExerciseComplete {
                exerciseCompletionView
            } else {
                if let exercise = selectedExercise {
                    Text("Exercise: \(exercise)")
                        .font(.headline)
                }
                
                if selectedExercise == nil {
                    exerciseSelection
                } else if isExerciseActive {
                    exerciseView
                } else {
                    exerciseDescription
                }
            }
        }
        .padding()
        .onReceive(timerPublisher) { _ in
            if isExerciseActive && remainingTime > 0 {
                remainingTime -= 1
            }
        }
        .onDisappear {
            timer?.invalidate()
        }
    }
    
    // MARK: - Exercise Selection
    private var exerciseSelection: some View {
        VStack(spacing: 15) {
            ForEach(exercises.keys.sorted(), id: \.self) { exercise in
                Button {
                    selectedExercise = exercise
                } label: {
                    HStack {
                        Image(systemName: iconName(for: exercise))
                            .font(.system(size: 24))
                        Text(exercise)
                            .font(.headline)
                        Spacer()
                        Image(systemName: "chevron.right")
                    }
                    .padding()
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(10)
                }
            }
        }
    }
    
    // MARK: - Exercise Description
    private var exerciseDescription: some View {
        VStack(spacing: 20) {
            if let exercise = selectedExercise, let timing = exercises[exercise] {
                Text("\(exercise) Breathing")
                    .font(.title2)
                    .fontWeight(.bold)
                
                VStack(alignment: .leading, spacing: 12) {
                    Text("• Inhale for \(timing.inhale) seconds")
                    if timing.hold > 0 {
                        Text("• Hold for \(timing.hold) seconds")
                    }
                    Text("• Exhale for \(timing.exhale) seconds")
                }
                .padding()
                
                Button {
                    currentRound = 1
                    startExercise()
                } label: {
                    Text("Start Exercise (\(totalRounds) Rounds)")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                
                Button {
                    selectedExercise = nil
                } label: {
                    Text("Back to Exercises")
                        .foregroundColor(.blue)
                }
            }
        }
    }
    
    // MARK: - Active Exercise View
    private var exerciseView: some View {
        VStack(spacing: 30) {
            Text("Round \(currentRound) of \(totalRounds)")
                .font(.headline)
            
            ProgressView(value: Double(currentRound - 1), total: Double(totalRounds))
                .padding(.horizontal, 40)
            
            Text(currentStepText)
                .font(.system(size: 40, weight: .bold))
                .foregroundColor(.blue)
            
            Image(systemName: currentStepImage)
                .font(.system(size: 100))
                .foregroundColor(.blue)
            
            Text("Time left: \(remainingTime)s")
                .font(.subheadline)
                .foregroundColor(.gray)
            
            Button {
                stopExercise()
            } label: {
                Text("Stop")
                    .foregroundColor(.red)
                    .padding()
                    .background(Color.red.opacity(0.1))
                    .cornerRadius(10)
            }
        }
    }
    
    // MARK: - Exercise Completion View
    private var exerciseCompletionView: some View {
        VStack(spacing: 20) {
            HStack(spacing: 10) {
                Text("Done!")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                Image(systemName: "checkmark.circle")
                    .foregroundColor(.green)
                    .font(.system(size: 40))
            }
            
            Text("How helpful was this exercise?")
                .font(.headline)
            
            HStack {
                ForEach(1...5, id: \.self) { star in
                    Image(systemName: starRating >= star ? "star.fill" : "star")
                        .foregroundColor(.yellow)
                        .font(.system(size: 32))
                        .onTapGesture {
                            starRating = star
                        }
                }
            }
            
            
            Button("Close") {
                isExerciseComplete = false
                starRating = 0
                selectedExercise = nil
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
        .padding()
    }
    
    // MARK: - Exercise Logic
    private func startExercise() {
        isExerciseActive = true
        currentStep = 0
        scheduleNextStep()
    }
    
    private func stopExercise() {
        timer?.invalidate()
        timer = nil
        isExerciseActive = false
        currentStep = 0
    }
    
    private func scheduleNextStep() {
        guard let exerciseName = selectedExercise, let timing = exercises[exerciseName] else { return }
        
        let duration: TimeInterval = {
            switch currentStep {
            case 0: return TimeInterval(timing.inhale)
            case 1: return TimeInterval(timing.hold)
            case 2: return TimeInterval(timing.exhale)
            default: return 0
            }
        }()
        
        if currentStep == 1 && timing.hold == 0 {
            currentStep = 2
        }
        
        remainingTime = Int(duration)
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: duration, repeats: false) { _ in
            DispatchQueue.main.async {
                advanceExerciseStep()
            }
        }
    }
    
    private func advanceExerciseStep() {
        guard let exerciseName = selectedExercise, let timing = exercises[exerciseName] else { return }
        
        if currentStep == 2 {
            if currentRound >= totalRounds {
                stopExercise()
                isExerciseComplete = true
                return
            } else {
                currentRound += 1
                currentStep = 0
            }
        } else {
            currentStep += 1
        }
        
        if currentStep == 1 && timing.hold == 0 {
            currentStep = 2
        }
        scheduleNextStep()
    }
    
    // MARK: - Display Helpers
    private var currentStepText: String {
        switch currentStep {
        case 0: return "Inhale"
        case 1: return "Hold"
        case 2: return "Exhale"
        default: return ""
        }
    }
    
    private var currentStepImage: String {
        switch currentStep {
        case 0: return "arrow.up.circle.fill"
        case 1: return "pause.circle.fill"
        case 2: return "arrow.down.circle.fill"
        default: return "circle.fill"
        }
    }
    
    private func iconName(for exercise: String) -> String {
        switch exercise {
        case "Relax": return "cloud.fill"
        case "Focus": return "brain.head.profile"
        case "Calm":  return "heart.fill"
        default:     return "questionmark.circle"
        }
    }
}
